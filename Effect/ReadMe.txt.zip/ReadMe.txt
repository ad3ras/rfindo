add following line to your MagicSptList.spt:

0xF1A30D01	\\item\rift_exit_mag.spt